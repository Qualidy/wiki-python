from my_casino.casino_games import play_game

print("Die Spiele mögen beginnen!")

play_game()
