def input_int_in_between(prompt, minimum, maximum):
    user_input = 0
    while True:
        try:
            user_input = int(input(prompt))
        except ValueError:
            print(f"Eingabe ist nicht vom Typ int")

        if minimum <= user_input <= maximum:
            return user_input
        else:
            print(f"Eingabe ist nicht gültig.")
